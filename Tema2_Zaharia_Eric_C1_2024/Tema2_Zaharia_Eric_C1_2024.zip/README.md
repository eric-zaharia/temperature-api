Zaharia Eric-Alexandru, 345C1
Tema 2 SCD

Tema se ruleaza folosind:
```` bash
docker-compose up --build
````
