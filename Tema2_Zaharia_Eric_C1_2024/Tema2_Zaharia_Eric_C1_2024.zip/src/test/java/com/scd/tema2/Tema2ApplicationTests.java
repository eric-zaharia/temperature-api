package com.scd.tema2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tema2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
